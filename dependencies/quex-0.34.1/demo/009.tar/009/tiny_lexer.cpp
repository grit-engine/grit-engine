#include"tiny_lexer"
namespace quex {
        QuexMode  tiny_lexer::ONE_AND_ONLY;
#define self  (*me)

    void
    tiny_lexer_ONE_AND_ONLY_on_entry(tiny_lexer* me, const QuexMode* FromMode) {
#ifdef __QUEX_OPTION_RUNTIME_MODE_TRANSITION_CHECK
__quex_assert(me->ONE_AND_ONLY.has_entry_from(FromMode));
#endif

    }

    void
    tiny_lexer_ONE_AND_ONLY_on_exit(tiny_lexer* me, const QuexMode* ToMode)  {
#ifdef __QUEX_OPTION_RUNTIME_MODE_TRANSITION_CHECK
__quex_assert(me->ONE_AND_ONLY.has_exit_to(ToMode));
#endif

    }

#ifdef __QUEX_OPTION_INDENTATION_TRIGGER_SUPPORT        
    void
    tiny_lexer_ONE_AND_ONLY_on_indentation(tiny_lexer* me, const int Indentation) {
__quex_assert(Indentation >= 0);
    }
#endif

#ifdef __QUEX_OPTION_RUNTIME_MODE_TRANSITION_CHECK
    bool
    tiny_lexer_ONE_AND_ONLY_has_base(const QuexMode* Mode) {
    return false;
    }
    bool
    tiny_lexer_ONE_AND_ONLY_has_entry_from(const QuexMode* Mode) {
    return true; // default
    }
    bool
    tiny_lexer_ONE_AND_ONLY_has_exit_to(const QuexMode* Mode) {
    return true; // default
    }
#endif    
#undef self
} // END: namespace quex

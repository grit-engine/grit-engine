#include "tiny_lexer"
#if ! defined(__QUEX_SETTING_PLAIN_C)
namespace quex {
#endif
#define QUEX_LEXER_CLASS tiny_lexer

#include <quex/code_base/template/Analyser>
#include <quex/code_base/buffer/Buffer>

#ifdef CONTINUE
#   undef CONTINUE
#endif
#define CONTINUE  goto __REENTRY_PREPARATION;
#include <quex/code_base/temporary_macros_on>

__QUEX_SETTING_ANALYSER_FUNCTION_RETURN_TYPE  
tiny_lexer_ONE_AND_ONLY_analyser_function(QuexAnalyser* me) 
{
    /* NOTE: Different modes correspond to different analyser functions. The analyser*/
    /*       functions are all located inside the main class as static functions. That*/
    /*       means, they are something like 'globals'. They receive a pointer to the */
    /*       lexical analyser, since static member do not have access to the 'this' pointer.*/
#   if defined (__QUEX_SETTING_PLAIN_C)
#      define self (*me)
#   else
       using namespace quex;
       QUEX_LEXER_CLASS& self = *((QUEX_LEXER_CLASS*)me);
#   endif
    /* me = pointer to state of the lexical analyser */
    quex::QuexMode&              ONE_AND_ONLY = QUEX_LEXER_CLASS::ONE_AND_ONLY;
    QUEX_GOTO_LABEL_TYPE         last_acceptance = QUEX_GOTO_TERMINAL_LABEL_INIT_VALUE;
    QUEX_CHARACTER_POSITION_TYPE last_acceptance_input_position = (QUEX_CHARACTER_TYPE*)(0x00);
    QUEX_CHARACTER_POSITION_TYPE* post_context_start_position = 0x0;
    QUEX_CHARACTER_TYPE          input = (QUEX_CHARACTER_TYPE)(0x00);

    /* Post context positions do not have to be reset or initialized. If a state
     * is reached which is associated with 'end of post context' it is clear what
     * post context is meant. This results from the ways the state machine is 
     * constructed. A post context positions live time looks like the following:
     *
     * (1)   unitialized (don't care)
     * (1.b) on buffer reload it may, or may not be adapted (don't care)
     * (2)   when a post context begin state is passed, the it is **SET** (now: take care)
     * (2.b) on buffer reload it **is adapted**.
     * (3)   when a terminal state of the post context is reached (which can only be reached
     *       for that particular post context, then the post context position is used
     *       to reset the input position.                                              */
#if    defined(QUEX_OPTION_AUTOMATIC_ANALYSIS_CONTINUATION_ON_MODE_CHANGE) \
    || defined(QUEX_OPTION_ASSERTS)
    me->DEBUG_analyser_function_at_entry = me->current_analyser_function;
#endif
__REENTRY:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: __REENTRY");
    QuexBuffer_mark_lexeme_start(&me->buffer);
    QuexBuffer_undo_terminating_zero_for_lexeme(&me->buffer);
    /* state machine */
    /* init-state = 365L
     * 00365() <~ (0, 0), (19, 150), (38, 292)
     *       == ['\t', '\n'], ' ' ==> 00369
     *       == 'b' ==> 00368
     *       == 'h' ==> 00370
     *       == 'l' ==> 00367
     *       == 'w' ==> 00366
     *       <no epsilon>
     * 00366() <~ (38, 294)
     *       == 'e' ==> 00387
     *       == 'o' ==> 00388
     *       <no epsilon>
     * 00387() <~ (38, 298)
     *       == 'l' ==> 00391
     *       <no epsilon>
     * 00391() <~ (38, 299)
     *       == 't' ==> 00386
     *       <no epsilon>
     * 00386(A, S) <~ (38, 290, A, S)
     *       <no epsilon>
     * 00388() <~ (38, 296)
     *       == 'r' ==> 00389
     *       <no epsilon>
     * 00389() <~ (38, 295)
     *       == 'l' ==> 00390
     *       <no epsilon>
     * 00390() <~ (38, 297)
     *       == 'd' ==> 00386
     *       <no epsilon>
     * 00367() <~ (38, 293)
     *       == 'e' ==> 00380
     *       <no epsilon>
     * 00380() <~ (38, 300)
     *       == ' ' ==> 00381
     *       <no epsilon>
     * 00381() <~ (38, 301)
     *       == 'm' ==> 00382
     *       <no epsilon>
     * 00382() <~ (38, 302)
     *       == 'o' ==> 00383
     *       <no epsilon>
     * 00383() <~ (38, 303)
     *       == 'n' ==> 00384
     *       <no epsilon>
     * 00384() <~ (38, 289)
     *       == 'd' ==> 00385
     *       <no epsilon>
     * 00385() <~ (38, 291)
     *       == 'e' ==> 00386
     *       <no epsilon>
     * 00368() <~ (19, 143)
     *       == 'o' ==> 00375
     *       <no epsilon>
     * 00375() <~ (19, 140)
     *       == 'n' ==> 00376
     *       <no epsilon>
     * 00376() <~ (19, 142)
     *       == 'j' ==> 00377
     *       <no epsilon>
     * 00377() <~ (19, 145)
     *       == 'o' ==> 00378
     *       <no epsilon>
     * 00378() <~ (19, 144)
     *       == 'u' ==> 00379
     *       <no epsilon>
     * 00379() <~ (19, 146)
     *       == 'r' ==> 00374
     *       <no epsilon>
     * 00374(A, S) <~ (19, 141, A, S)
     *       <no epsilon>
     * 00369(A, S) <~ (0, 1, A, S)
     *       <no epsilon>
     * 00370() <~ (19, 151)
     *       == 'a', 'e' ==> 00371
     *       <no epsilon>
     * 00371() <~ (19, 148)
     *       == 'l' ==> 00372
     *       <no epsilon>
     * 00372() <~ (19, 147)
     *       == 'l' ==> 00373
     *       <no epsilon>
     * 00373() <~ (19, 149)
     *       == 'o' ==> 00374
     *       <no epsilon>
     * 
     */
STATE_365:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_365");

    input = QuexBuffer_input_get(&me->buffer);
    if( input < 99) {
        if( input < 32) {
            if( input == 9 || input == 10 ) {
                QuexBuffer_input_p_increment(&me->buffer);
                goto TERMINAL_0_DIRECT;
            } else {
                goto STATE_365_DROP_OUT;
            }
        } else {
            if( input < 33) {
                    QuexBuffer_input_p_increment(&me->buffer);
                goto TERMINAL_0_DIRECT;    /* ' ' */
            } else {
                if( input != 98) {
                    goto STATE_365_DROP_OUT_DIRECT;    /* ['!', 'a'] */
                } else {
                    goto STATE_368;    /* 'b' */
                }
            }
        }
    } else {
        if( input < 108) {
            if( input == 104) {
                goto STATE_370;    /* 'h' */
            } else {
                goto STATE_365_DROP_OUT_DIRECT;    /* ['c', 'g'] */
            }
        } else {
            if( input < 119) {
                if( input == 108) {
                    goto STATE_367;    /* 'l' */
                } else {
                    goto STATE_365_DROP_OUT_DIRECT;    /* ['m', 'v'] */
                }
            } else {
                if( input == 119) {
                    goto STATE_366;    /* 'w' */
                } else {
                    goto STATE_365_DROP_OUT_DIRECT;    /* ['x', oo] */
                }
            }
        }
    }

STATE_365_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_365_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_365_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_365_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

    if( QuexBuffer_is_end_of_file(&me->buffer) ) {
        /* NO CHECK 'last_acceptance != -1' --- first state can **never** be an acceptance state */
        goto TERMINAL_END_OF_STREAM;
    }
        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_365_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();


STATE_365_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_365_INPUT");
    QuexBuffer_input_p_increment(&me->buffer);
    goto STATE_365;
STATE_384:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_384");

STATE_384_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_384_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 100) {
        goto STATE_385;    /* 'd' */
    } else {
        goto STATE_384_DROP_OUT;    /* [-oo, 'c'] */
    }

STATE_384_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_384_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_384_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_384_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_384_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_385:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_385");

STATE_385_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_385_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 101) {
        QuexBuffer_input_p_increment(&me->buffer);
        goto TERMINAL_38_DIRECT;    /* 'e' */
    } else {
        goto STATE_385_DROP_OUT;    /* [-oo, 'd'] */
    }

STATE_385_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_385_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_385_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_385_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_385_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_387:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_387");

STATE_387_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_387_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 108) {
        goto STATE_391;    /* 'l' */
    } else {
        goto STATE_387_DROP_OUT;    /* [-oo, 'k'] */
    }

STATE_387_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_387_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_387_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_387_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_387_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_388:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_388");

STATE_388_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_388_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 114) {
        goto STATE_389;    /* 'r' */
    } else {
        goto STATE_388_DROP_OUT;    /* [-oo, 'q'] */
    }

STATE_388_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_388_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_388_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_388_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_388_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_389:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_389");

STATE_389_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_389_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 108) {
        goto STATE_390;    /* 'l' */
    } else {
        goto STATE_389_DROP_OUT;    /* [-oo, 'k'] */
    }

STATE_389_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_389_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_389_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_389_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_389_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_390:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_390");

STATE_390_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_390_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 100) {
        QuexBuffer_input_p_increment(&me->buffer);
        goto TERMINAL_38_DIRECT;    /* 'd' */
    } else {
        goto STATE_390_DROP_OUT;    /* [-oo, 'c'] */
    }

STATE_390_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_390_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_390_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_390_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_390_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_391:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_391");

STATE_391_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_391_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 116) {
        QuexBuffer_input_p_increment(&me->buffer);
        goto TERMINAL_38_DIRECT;    /* 't' */
    } else {
        goto STATE_391_DROP_OUT;    /* [-oo, 's'] */
    }

STATE_391_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_391_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_391_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_391_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_391_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_366:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_366");

STATE_366_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_366_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input < 102) {
        if( input != 101) {
            goto STATE_366_DROP_OUT;    /* [-oo, 'd'] */
        } else {
            goto STATE_387;    /* 'e' */
        }
    } else {
        if( input == 111) {
            goto STATE_388;    /* 'o' */
        } else {
            goto STATE_366_DROP_OUT_DIRECT;    /* ['f', 'n'] */
        }
    }

STATE_366_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_366_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_366_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_366_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_366_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_367:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_367");

STATE_367_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_367_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 101) {
        goto STATE_380;    /* 'e' */
    } else {
        goto STATE_367_DROP_OUT;    /* [-oo, 'd'] */
    }

STATE_367_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_367_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_367_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_367_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_367_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_368:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_368");

STATE_368_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_368_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 111) {
        goto STATE_375;    /* 'o' */
    } else {
        goto STATE_368_DROP_OUT;    /* [-oo, 'n'] */
    }

STATE_368_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_368_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_368_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_368_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_368_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_370:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_370");

STATE_370_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_370_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 97 || input == 101 ) {
        goto STATE_371;
    } else {
        goto STATE_370_DROP_OUT;
    }

STATE_370_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_370_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_370_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_370_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_370_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_371:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_371");

STATE_371_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_371_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 108) {
        goto STATE_372;    /* 'l' */
    } else {
        goto STATE_371_DROP_OUT;    /* [-oo, 'k'] */
    }

STATE_371_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_371_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_371_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_371_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_371_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_372:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_372");

STATE_372_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_372_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 108) {
        goto STATE_373;    /* 'l' */
    } else {
        goto STATE_372_DROP_OUT;    /* [-oo, 'k'] */
    }

STATE_372_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_372_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_372_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_372_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_372_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_373:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_373");

STATE_373_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_373_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 111) {
        QuexBuffer_input_p_increment(&me->buffer);
        goto TERMINAL_19_DIRECT;    /* 'o' */
    } else {
        goto STATE_373_DROP_OUT;    /* [-oo, 'n'] */
    }

STATE_373_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_373_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_373_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_373_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_373_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_375:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_375");

STATE_375_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_375_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 110) {
        goto STATE_376;    /* 'n' */
    } else {
        goto STATE_375_DROP_OUT;    /* [-oo, 'm'] */
    }

STATE_375_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_375_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_375_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_375_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_375_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_376:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_376");

STATE_376_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_376_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 106) {
        goto STATE_377;    /* 'j' */
    } else {
        goto STATE_376_DROP_OUT;    /* [-oo, 'i'] */
    }

STATE_376_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_376_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_376_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_376_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_376_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_377:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_377");

STATE_377_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_377_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 111) {
        goto STATE_378;    /* 'o' */
    } else {
        goto STATE_377_DROP_OUT;    /* [-oo, 'n'] */
    }

STATE_377_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_377_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_377_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_377_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_377_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_378:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_378");

STATE_378_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_378_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 117) {
        goto STATE_379;    /* 'u' */
    } else {
        goto STATE_378_DROP_OUT;    /* [-oo, 't'] */
    }

STATE_378_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_378_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_378_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_378_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_378_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_379:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_379");

STATE_379_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_379_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 114) {
        QuexBuffer_input_p_increment(&me->buffer);
        goto TERMINAL_19_DIRECT;    /* 'r' */
    } else {
        goto STATE_379_DROP_OUT;    /* [-oo, 'q'] */
    }

STATE_379_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_379_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_379_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_379_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_379_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_380:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_380");

STATE_380_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_380_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 32) {
        goto STATE_381;    /* ' ' */
    } else {
        goto STATE_380_DROP_OUT;    /* [-oo, \31] */
    }

STATE_380_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_380_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_380_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_380_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_380_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_381:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_381");

STATE_381_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_381_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 109) {
        goto STATE_382;    /* 'm' */
    } else {
        goto STATE_381_DROP_OUT;    /* [-oo, 'l'] */
    }

STATE_381_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_381_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_381_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_381_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_381_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_382:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_382");

STATE_382_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_382_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 111) {
        goto STATE_383;    /* 'o' */
    } else {
        goto STATE_382_DROP_OUT;    /* [-oo, 'n'] */
    }

STATE_382_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_382_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_382_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_382_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_382_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();



STATE_383:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_383");

STATE_383_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_383_INPUT");

    QuexBuffer_input_p_increment(&me->buffer);
    input = QuexBuffer_input_get(&me->buffer);
    if( input == 110) {
        goto STATE_384;    /* 'n' */
    } else {
        goto STATE_383_DROP_OUT;    /* [-oo, 'm'] */
    }

STATE_383_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_383_DROP_OUT");
    if( input != QUEX_SETTING_BUFFER_LIMIT_CODE ) {
STATE_383_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_383_DROP_OUT_DIRECT");
        QUEX_GOTO_last_acceptance();

    }

        QUEX_DEBUG_PRINT(&me->buffer, "FORWARD_BUFFER_RELOAD");
    if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                           post_context_start_position, 0) ) {
       goto STATE_383_INPUT;
    }

    QUEX_DEBUG_PRINT(&me->buffer, "BUFFER_RELOAD_FAILED");
    QUEX_GOTO_last_acceptance();




  /* (*) Terminal states _______________________________________________________*/
  /**/
  /* Acceptance terminal states, i.e. the 'winner patterns'. This means*/
  /* that the last input dropped out of a state where the longest matching*/
  /* pattern was according to the terminal state. The terminal states are */
  /* numbered after the pattern id.*/
  /**/
#define Lexeme       (me->buffer._lexeme_start_p)
#define LexemeBegin  (me->buffer._lexeme_start_p)
#define LexemeEnd    (me->buffer._input_p)
#define LexemeL      (size_t)(me->buffer._input_p - me->buffer._lexeme_start_p)
TERMINAL_0:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: TERMINAL_0");

    QuexBuffer_seek_memory_adr(&me->buffer, last_acceptance_input_position);

TERMINAL_0_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: TERMINAL_0_DIRECT");

{
/* Character set skipper state */
{ 
    /* Skip any character in ['\t', '\n'], ' ' */

    QUEX_BUFFER_ASSERT_CONSISTENCY(&me->buffer);
    __quex_assert(QuexBuffer_content_size(&me->buffer) >= 1);
    if( QuexBuffer_distance_input_to_text_end(&me->buffer) == 0 ) 
        goto STATE_392_DROP_OUT;

    /* NOTE: For simple skippers the end of content does not have to be overwriten 
     *       with anything (as done for range skippers). This is so, because the abort
     *       criteria is that a character occurs which does not belong to the trigger 
     *       set. The BufferLimitCode, though, does never belong to any trigger set and
     *       thus, no special character is to be set.                                   */
STATE_392_INPUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_392_INPUT");

    input = QuexBuffer_input_get(&me->buffer); 
    if( input == 9 || input == 10 || input == 32 ) {
        goto STATE_392;
    } else {
        goto STATE_392_DROP_OUT;
    }


STATE_392:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_392");

    QuexBuffer_input_p_increment(&me->buffer); /* Now, BLC cannot occur. See above. */
    goto STATE_392_INPUT;

STATE_392_DROP_OUT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_392_DROP_OUT");

    /* -- When loading new content it is always taken care that the beginning of the lexeme
     *    is not 'shifted' out of the buffer. In the case of skipping, we do not care about
     *    the lexeme at all, so do not restrict the load procedure and set the lexeme start
     *    to the actual input position.                                                   
     * -- The input_p will at this point in time always point to the buffer border.        */
    if( QuexBuffer_distance_input_to_text_end(&me->buffer) == 0 ) {
        QUEX_BUFFER_ASSERT_CONSISTENCY(&me->buffer);
        QuexBuffer_mark_lexeme_start(&me->buffer);
        if( QuexAnalyser_buffer_reload_forward(&me->buffer, &last_acceptance_input_position,
                                               post_context_start_position, 0) ) {

            QUEX_BUFFER_ASSERT_CONSISTENCY(&me->buffer);
            QuexBuffer_input_p_increment(&me->buffer);
            goto STATE_392_INPUT;
        } else {
            goto TERMINAL_END_OF_STREAM;
        }
    }

STATE_392_DROP_OUT_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: STATE_392_DROP_OUT_DIRECT");

    /* There was no buffer limit code, so no end of buffer or end of file --> continue analysis 
     * The character we just swallowed must be re-considered by the main state machine.
     * But, note that the initial state does not increment '_input_p'!
     */
    goto __REENTRY_PREPARATION;                           
}

}

    goto __REENTRY_PREPARATION;

TERMINAL_19:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: TERMINAL_19");

    QuexBuffer_seek_memory_adr(&me->buffer, last_acceptance_input_position);

TERMINAL_19_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: TERMINAL_19_DIRECT");

    QuexBuffer_set_terminating_zero_for_lexeme(&me->buffer);
    {
        {
        self.counter.__shift_end_values_to_start_values();
        self.counter.count_NoNewline(LexemeL);
        
        #line 12 "simple.qx"
        #ifdef QUEX_OPTION_TOKEN_SENDING_VIA_QUEUE
        self.send(QUEX_TKN_HELLO, Lexeme); return;
        #else
        self.send(Lexeme); return QUEX_TKN_HELLO;
        #endif
#line 1121 "tiny_lexer-core-engine.cpp"
        
        }
    }

    goto __REENTRY_PREPARATION;

TERMINAL_38:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: TERMINAL_38");

    QuexBuffer_seek_memory_adr(&me->buffer, last_acceptance_input_position);

TERMINAL_38_DIRECT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: TERMINAL_38_DIRECT");

    QuexBuffer_set_terminating_zero_for_lexeme(&me->buffer);
    {
        {
        self.counter.__shift_end_values_to_start_values();
        self.counter.count_NoNewline(LexemeL);
        
        #line 13 "simple.qx"
        #ifdef QUEX_OPTION_TOKEN_SENDING_VIA_QUEUE
        self.send(QUEX_TKN_WORLD, Lexeme); return;
        #else
        self.send(Lexeme); return QUEX_TKN_WORLD;
        #endif
#line 1148 "tiny_lexer-core-engine.cpp"
        
        }
    }

    goto __REENTRY_PREPARATION;



TERMINAL_END_OF_STREAM:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: TERMINAL_END_OF_STREAM");

                {
                    {
        self.counter.__shift_end_values_to_start_values();
        
        #line 10 "simple.qx"
        #ifdef QUEX_OPTION_TOKEN_SENDING_VIA_QUEUE
        self.send(QUEX_TKN_TERMINATION); return;
        #else
        self.send(); return QUEX_TKN_TERMINATION;
        #endif
#line 1170 "tiny_lexer-core-engine.cpp"
        
        }
                }

#ifdef __QUEX_OPTION_ANALYSER_RETURN_TYPE_IS_VOID
        return /*__QUEX_TOKEN_ID_TERMINATION*/;
#else
        return __QUEX_TOKEN_ID_TERMINATION;
#endif

TERMINAL_DEFAULT:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: TERMINAL_DEFAULT");

me->buffer._input_p = me->buffer._lexeme_start_p;
if( QuexBuffer_is_end_of_file(&me->buffer) ) {

    /* Next increment will stop on EOF character. */
}

else {
    /* Step over nomatching character */    QuexBuffer_input_p_increment(&me->buffer);
}

                QuexBuffer_set_terminating_zero_for_lexeme(&me->buffer);
                {
                    {
        self.counter.__shift_end_values_to_start_values();
        self.counter.count(Lexeme, LexemeEnd);
        self.send(QUEX_TKN_TERMINATION);
        #ifdef __QUEX_OPTION_ANALYSER_RETURN_TYPE_IS_VOID
            return /*__QUEX_TOKEN_ID_TERMINATION*/;
        #else
            return __QUEX_TOKEN_ID_TERMINATION;
        #endif
        
        }
                }

        goto __REENTRY_PREPARATION;

#undef Lexeme
#undef LexemeBegin
#undef LexemeEnd
#undef LexemeL
#ifndef __QUEX_OPTION_USE_COMPUTED_GOTOS
__TERMINAL_ROUTER: {
        /*  if last_acceptance => goto correspondent acceptance terminal state*/
        /*  else               => execute defaul action*/
        switch( last_acceptance ) {
            case 0: goto TERMINAL_0;
            case 19: goto TERMINAL_19;
            case 38: goto TERMINAL_38;

            default: goto TERMINAL_DEFAULT;; /* nothing matched */
        }
    }
#endif /* __QUEX_OPTION_USE_COMPUTED_GOTOS */

  
__REENTRY_PREPARATION:
    QUEX_DEBUG_PRINT(&me->buffer, "LABEL: __REENTRY_PREPARATION");

    /* (*) Common point for **restarting** lexical analysis.
     *     at each time when CONTINUE is called at the end of a pattern. */
    last_acceptance = QUEX_GOTO_TERMINAL_LABEL_INIT_VALUE;


    /* Post context positions do not have to be reset or initialized. If a state
     * is reached which is associated with 'end of post context' it is clear what
     * post context is meant. This results from the ways the state machine is 
     * constructed. A post context positions live time looks like the following:
     *
     * (1)   unitialized (don't care)
     * (1.b) on buffer reload it may, or may not be adapted (don't care)
     * (2)   when a post context begin state is passed, the it is **SET** (now: take care)
     * (2.b) on buffer reload it **is adapted**.
     * (3)   when a terminal state of the post context is reached (which can only be reached
     *       for that particular post context, then the post context position is used
     *       to reset the input position.                                              */

    /*  If a mode change happened, then the function must first return and
     *  indicate that another mode function is to be called. At this point, 
     *  we to force a 'return' on a mode change. 
     *
     *  Pseudo Code: if( previous_mode != current_mode ) {
     *                   return 0;
     *               }
     *
     *  When the analyzer returns, the caller function has to watch if a mode change
     *  occured. If not it can call this function again.                               */
#if    defined(QUEX_OPTION_AUTOMATIC_ANALYSIS_CONTINUATION_ON_MODE_CHANGE)     || defined(QUEX_OPTION_ASSERTS)
    if( me->DEBUG_analyser_function_at_entry != me->current_analyser_function ) 
#endif
    { 
#if defined(QUEX_OPTION_AUTOMATIC_ANALYSIS_CONTINUATION_ON_MODE_CHANGE)
#   ifdef __QUEX_OPTION_ANALYSER_RETURN_TYPE_IS_VOID
       return /*__QUEX_TOKEN_ID_UNINITIALIZED*/;
#   else
       return __QUEX_TOKEN_ID_UNINITIALIZED;
#   endif
#elif defined(QUEX_OPTION_ASSERTS)
       QUEX_ERROR_EXIT("Mode change without immediate return from the lexical analyser.");
#endif
    }

    goto __REENTRY;

    /* prevent compiler warning 'unused variable': use variables once in a part of the code*/
    /* that is never reached (and deleted by the compiler anyway).*/
    if( 0 == 1 ) {
        int unused = 0;
        unused = unused + ONE_AND_ONLY.id;
    }
}
#include <quex/code_base/temporary_macros_off>
#if ! defined(__QUEX_SETTING_PLAIN_C)
} // namespace quex
#endif
